// ast.c

#include "ast.h"

// Function Implementations

// Create a new AST node
ASTNode* create_ast_node(NodeType type) {
    ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
    if (!node) {
        fprintf(stderr, "Error: Unable to allocate memory for AST node.\n");
        exit(1);
    }
    node->node_type = type;
    node->name = NULL;
    node->data_type = NULL;
    node->left = NULL;
    node->right = NULL;
    node->child = NULL;
    node->next = NULL;  // Ensure next is initialized to NULL
    node->value = 0;
    node->float_value = 0.0f;
    node->num_dimensions = 0;
    for(int i = 0; i < MAX_DIMENSIONS; i++) {
        node->sizes[i] = 0;
    }
    node->params = NULL;
    node->args = NULL;

    printf("DEBUG: Created new AST node at %p, type: %d\n", (void*)node, type);
    return node;
}

// Program Node
ASTNode* create_program_node(ASTNode* functions, ASTNode* main_func) {
    ASTNode* node = create_ast_node(NODE_PROGRAM);
    node->child = functions;
    node->next = main_func;
    return node;
}

// Add to Function List
ASTNode* add_to_function_list(ASTNode* list, ASTNode* func) {
    if (!list) {
        return func;
    }
    ASTNode* current = list;
    while (current->next) {
        current = current->next;
    }
    current->next = func;
    return list;
}

// Function Definition Node
ASTNode* create_function_def_node(const char* return_type, const char* name, ASTParamNode* params, ASTNode* body) {
    ASTNode* node = create_ast_node(NODE_FUNCTION_DEF);
    node->data_type = strdup(return_type);
    node->name = strdup(name);
    node->params = params; // AST parameters
    node->child = body; // BODY is now NODE_BLOCK
    return node;
}

// Main Function Node
ASTNode* create_main_function_node(ASTNode* body) {
    ASTNode* node = create_ast_node(NODE_MAIN_FUNCTION);
    node->child = body; // BODY is now NODE_BLOCK
    return node;
}

// Parameter Node (renamed)
ASTParamNode* create_ast_param_node(const char* type, const char* name) {
    ASTParamNode* param = (ASTParamNode*)malloc(sizeof(ASTParamNode));
    if (!param) {
        fprintf(stderr, "Error: Unable to allocate memory for AST parameter node.\n");
        exit(1);
    }
    param->type = strdup(type);
    param->name = strdup(name);
    param->next = NULL;
    return param;
}

// Parameter List Node
ASTNode* create_ast_param_list_node(ASTParamNode* param) {
    ASTNode* node = create_ast_node(NODE_AST_PARAM_LIST);
    node->params = param;
    return node;
}

// Add to Parameter List
ASTParamNode* add_to_ast_param_list(ASTParamNode* list, ASTParamNode* param) {
    if (!list) {
        return param;
    }
    ASTParamNode* current = list;
    while (current->next) {
        current = current->next;
    }
    current->next = param;
    return list;
}

// Add AST Param to ASTParamList
ASTParamList* add_ast_param(ASTParamList* list, ASTParamNode* param_node) {
    if (!list) {
        list = (ASTParamList*)malloc(sizeof(ASTParamList));
        if (!list) {
            fprintf(stderr, "Error: Unable to allocate memory for ASTParamList.\n");
            exit(1);
        }
        list->params = NULL;
    }
    if (!list->params) {
        list->params = param_node;
    } else {
        ASTParamNode* current = list->params;
        while (current->next) {
            current = current->next;
        }
        current->next = param_node;
    }
    return list;
}

// Variable Declaration Node
ASTNode* create_var_decl_node(const char* type, const char* name, ASTNode* array_sizes, ASTNode* initializer) {
    ASTNode* node = create_ast_node(NODE_VAR_DECL);
    node->data_type = strdup(type);
    node->name = strdup(name);
    node->child = array_sizes;
    node->right = initializer;
    return node;
}

// Array Declaration Node
ASTNode* create_array_decl_node(const char* type, const char* name, ASTNode* array_sizes, ASTNode* initializer) {
    ASTNode* node = create_ast_node(NODE_ARRAY_DECL);
    node->data_type = strdup(type);
    node->name = strdup(name);
    node->child = array_sizes;
    node->right = initializer;
    return node;
}

// Assignment Node
ASTNode* create_assignment_node(const char* name, ASTNode* expr) {
    ASTNode* node = create_ast_node(NODE_ASSIGNMENT);
    node->name = strdup(name);
    node->child = expr;
    return node;
}

// Array Assignment Node
ASTNode* create_array_assignment_node(const char* name, ASTNode* index, ASTNode* expr) {
    ASTNode* node = create_ast_node(NODE_ARRAY_ASSIGNMENT);
    node->name = strdup(name);
    node->child = index;
    node->right = expr;
    return node;
}

// Write Statement Node
ASTNode* create_write_node(const char* name) {
    ASTNode* node = create_ast_node(NODE_WRITE);
    node->name = strdup(name);
    return node;
}

// Write Array Element Node
ASTNode* create_write_node_with_access(const char* name, ASTNode* index) {
    ASTNode* node = create_ast_node(NODE_WRITE_ARRAY);
    node->name = strdup(name);
    node->child = index;
    return node;
}

// Binary Operation Node
ASTNode* create_binary_op_node(const char* op, ASTNode* left, ASTNode* right) {
    ASTNode* node = create_ast_node(NODE_BINARY_OP);
    node->name = strdup(op);
    node->left = left;
    node->right = right;
    return node;
}

// Function Call Node
ASTNode* create_function_call_node(const char* name, ASTNode* args) {
    ASTNode* node = create_ast_node(NODE_FUNCTION_CALL);
    node->name = strdup(name);
    node->args = args;
    return node;
}

// Array Access Node
ASTNode* create_array_access_node(const char* name, ASTNode* index) {
    ASTNode* node = create_ast_node(NODE_ARRAY_ACCESS);
    node->name = strdup(name);
    node->child = index;
    return node;
}

// Identifier Node
ASTNode* create_id_node(const char* name) {
    ASTNode* node = create_ast_node(NODE_ID);
    node->name = strdup(name);
    return node;
}

// Number Literal Node
ASTNode* create_number_node(int value) {
    ASTNode* node = create_ast_node(NODE_NUMBER);
    node->value = value;
    return node;
}

// Float Literal Node
ASTNode* create_float_node(float value) {
    ASTNode* node = create_ast_node(NODE_FLOAT);
    node->float_value = value;
    return node;
}

// Return Statement Node
ASTNode* create_return_node(ASTNode* expr) {
    ASTNode* node = create_ast_node(NODE_RETURN);
    node->child = expr;
    return node;
}

// Function Body Node
ASTNode* create_function_body_node(ASTNode* declarations, ASTNode* statements, ASTNode* return_stmt) {
    ASTNode* node = create_ast_node(NODE_BLOCK); // Use NODE_BLOCK
    node->child = declarations;
    node->left = statements;
    node->right = return_stmt;
    return node;
}

// Main Body Node
ASTNode* create_main_body_node(ASTNode* declarations, ASTNode* statements, ASTNode* return_stmt) {
    ASTNode* node = create_ast_node(NODE_BLOCK); // Use NODE_BLOCK
    node->child = declarations;
    node->left = statements;
    node->right = return_stmt;
    return node;
}

// Variable Declaration List
ASTNode* add_to_var_decl_list(ASTNode* list, ASTNode* decl) {
    if (!list) {
        return decl;
    }

    ASTNode* current = list;

    // Traverse to the last node in the list
    while (current->next) {
        printf("DEBUG: Traversing var decl list, current = %p, current->next = %p\n", (void*)current, (void*)current->next);
        current = current->next;
    }

    // Check `decl` and current->next before linking
    printf("DEBUG: Before linking var decl, current = %p, current->next = %p, decl = %p\n", (void*)current, (void*)current->next, (void*)decl);
    decl->next = NULL;  // Ensure decl’s next is NULL before linking
    current->next = decl;  // Link decl at the end of the list
    printf("DEBUG: Added var decl = %p to list, current->next now = %p\n", (void*)decl, (void*)current->next);

    return list;
}

// Statement List
ASTNode* add_to_stmt_list(ASTNode* list, ASTNode* stmt) {
    if (!list) {
        return stmt;
    }
    ASTNode* current = list;
    while (current->next) {
        current = current->next;
    }
    current->next = stmt;
    return list;
}

// Initializer List
ASTNode* add_to_initializer_list(ASTNode* list, ASTNode* initializer) {
    if (!list) {
        return initializer;
    }
    ASTNode* current = list;
    while (current->next) {
        current = current->next;
    }
    current->next = initializer;
    return list;
}

// Argument Node
ASTNode* create_arg_node(ASTNode* expr) {
    ASTNode* node = create_ast_node(NODE_ARG);
    node->child = expr;    // Set the child to the expression (e.g., Number node)
    node->next = NULL;     // Initialize next to NULL
    printf("DEBUG: Created Arg node at %p with child %p\n", (void*)node, (void*)expr);
    return node;
}

// Add to Argument List
ASTNode* add_to_arg_list(ASTNode* list, ASTNode* arg) {
    if (!list) {
        printf("DEBUG: Starting new Arg list with Arg node at %p\n", (void*)arg);
        return arg;
    }
    ASTNode* current = list;
    while (current->next) {
        current = current->next;
    }
    current->next = arg;
    printf("DEBUG: Linked Arg node at %p to Arg node at %p\n", (void*)current, (void*)arg);
    return list;
}

// Free AST
void free_ast(ASTNode* root) {
    if (!root) return;

    // Free children
    free_ast(root->left);
    free_ast(root->right);
    free_ast(root->child);
    free_ast(root->next);

    // Free allocated strings
    if (root->name) free(root->name);
    if (root->data_type) free(root->data_type);

    // Free ParamNode linked list
    if (root->params) {
        ASTParamNode* param = root->params;
        while (param) {
            ASTParamNode* next_param = param->next;
            if (param->type) free(param->type);
            if (param->name) free(param->name);
            free(param);
            param = next_param;
        }
    }

    // Free arguments linked list
    if (root->args) {
        free_ast(root->args);
    }

    free(root);
}

// Convert VarType enum to string
const char* var_type_to_string(VarType type) {
    switch (type) {
        case VAR_TYPE_INT:
            return "int";
        case VAR_TYPE_FLOAT:
            return "float";
        case VAR_TYPE_CHAR:
            return "char";
        default:
            return "unknown";
    }
}

// Create a new array size node
ASTNode* create_array_size_node(int size) {
    ASTNode* node = create_ast_node(NODE_ARRAY_SIZE);
    node->num_dimensions = 1;
    node->sizes[0] = size;
    return node;
}

// Add a size to an existing array size node
void add_array_size(ASTNode* node, int size) {
    if (node->num_dimensions >= MAX_DIMENSIONS) {
        fprintf(stderr, "Error: Maximum array dimensions exceeded\n");
        exit(1);
    }
    node->sizes[node->num_dimensions] = size;
    node->num_dimensions++;
}

// Traverse AST (for debugging)
void traverse_ast(ASTNode* node, int level) {
    if (!node) return;

    // Indentation
    for(int i = 0; i < level; i++) {
        printf("  ");
    }

    // Print node type and relevant information
    switch(node->node_type) {
        case NODE_PROGRAM:
            printf("Program\n");
            traverse_ast(node->child, level + 1); // Functions
            traverse_ast(node->next, level + 1);   // Main Function
            break;

        case NODE_FUNCTION_DEF:
            printf("Function Definition: %s, Return Type: %s\n", node->name, node->data_type);
            if (node->params) {
                printf("  Parameters:\n");
                ASTParamNode* param = node->params;
                while (param) {
                    for(int i = 0; i < level + 2; i++) printf("  ");
                    printf("Param: %s, Type: %s\n", param->name, param->type);
                    param = param->next;
                }
            }
            traverse_ast(node->child, level + 1); // Function body (NODE_BLOCK)
            break;

        case NODE_MAIN_FUNCTION:
            printf("Main Function\n");
            traverse_ast(node->child, level + 1); // Main body (NODE_BLOCK)
            break;

        case NODE_BLOCK:
            printf("Block:\n");
            traverse_ast(node->child, level + 1); // Declarations
            traverse_ast(node->left, level + 1);  // Statements
            traverse_ast(node->right, level + 1); // Return Statement
            break;

        case NODE_VAR_DECL:
            printf("Variable Declaration: %s, Type: %s\n", node->name, node->data_type);
            if (node->child) {
                printf("  Array Sizes:\n");
                for(int i = 0; i < node->child->num_dimensions; i++) {
                    for(int j = 0; j < level + 2; j++) printf("  ");
                    printf("Size[%d]: %d\n", i, node->child->sizes[i]);
                }
            }
            if (node->right) {
                printf("  Initializer:\n");
                traverse_ast(node->right, level + 2);
            }
            break;

        case NODE_ARRAY_DECL:
            printf("Array Declaration: %s, Type: %s, Dimensions: %d\n", node->name, node->data_type, node->num_dimensions);
            for(int i = 0; i < node->num_dimensions; i++) {
                for(int j = 0; j < level + 2; j++) printf("  ");
                printf("Size[%d]: %d\n", i, node->sizes[i]);
            }
            if (node->right) {
                printf("  Initializer:\n");
                traverse_ast(node->right, level + 2);
            }
            break;

        case NODE_ASSIGNMENT:
            printf("Assignment: %s\n", node->name);
            traverse_ast(node->child, level + 1); // Expression
            break;

        case NODE_ARRAY_ASSIGNMENT:
            printf("Array Assignment: %s\n", node->name);
            traverse_ast(node->child, level + 1); // Index
            traverse_ast(node->right, level + 1); // Expression
            break;

        case NODE_WRITE:
            printf("Write Statement: %s\n", node->name);
            break;

        case NODE_WRITE_ARRAY:
            printf("Write Array Element: %s\n", node->name);
            traverse_ast(node->child, level + 1); // Index
            break;

        case NODE_BINARY_OP:
            printf("Binary Operation: %s\n", node->name);
            traverse_ast(node->left, level + 1);
            traverse_ast(node->right, level + 1);
            break;

        case NODE_FUNCTION_CALL:
            printf("Function Call: %s\n", node->name);
            if (node->args) {
                printf("  Argument List:\n");
                ASTNode* current_arg = node->args;
                while (current_arg) {
                    for(int i = 0; i < level + 2; i++) printf("  ");
                    printf("Arg:\n");
                    if (current_arg->child) {
                        traverse_ast(current_arg->child, level + 3); // Argument expression
                    } else {
                        printf("    [Error] Arg node at %p has no child.\n", (void*)current_arg);
                    }
                    current_arg = current_arg->next;
                }
            }
            break;

        case NODE_ARRAY_ACCESS:
            printf("Array Access: %s\n", node->name);
            traverse_ast(node->child, level + 1); // Index
            break;

        case NODE_ID:
            printf("Identifier: %s\n", node->name);
            break;

        case NODE_NUMBER:
            printf("Number: %d\n", node->value);
            break;

        case NODE_FLOAT:
            printf("Float: %.2f\n", node->float_value);
            break;

        case NODE_RETURN:
            printf("Return Statement\n");
            traverse_ast(node->child, level + 1); // Expression
            break;

        // No need to handle NODE_ARG separately since it's handled within NODE_FUNCTION_CALL

        default:
            printf("Unknown Node Type\n");
    }
}
