// symbol_table.c

#include "symbol_table.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Global symbol table stack
static SymbolTable* symbol_table_stack = NULL;

// Helper function to create a new symbol table
static SymbolTable* create_symbol_table() {
    SymbolTable* table = (SymbolTable*)malloc(sizeof(SymbolTable));
    if (!table) {
        fprintf(stderr, "Error: Unable to allocate memory for symbol table.\n");
        exit(1);
    }
    table->symbols = NULL;
    table->next = NULL;
    printf("DEBUG: Created new SymbolTable at %p, symbols = %p, next = %p\n",
           (void*)table, (void*)table->symbols, (void*)table->next);
    return table;
}



static Symbol* create_symbol(const char* name, SymbolType symbol_type, VarType var_type, bool is_array, int num_dimensions, int* sizes) {
    if (name == NULL) {
        fprintf(stderr, "Error: Symbol name is NULL in create_symbol.\n");
        exit(1);
    }

    printf("DEBUG: Creating symbol with name = %s\n", name);

    Symbol* sym = (Symbol*)malloc(sizeof(Symbol));
    if (!sym) {
        fprintf(stderr, "Error: Unable to allocate memory for symbol.\n");
        exit(1);
    }
    
    sym->name = strdup(name);
    if (sym->name == NULL) {
        fprintf(stderr, "Error: strdup failed for symbol name '%s'.\n", name);
        exit(1);
    }

    sym->symbol_type = symbol_type;
    sym->var_type = var_type;
    sym->is_array = is_array;
    sym->num_dimensions = num_dimensions;
    sym->sizes = is_array ? malloc(num_dimensions * sizeof(int)) : NULL;
    
    if (is_array && num_dimensions > 0 && !sym->sizes) {
        fprintf(stderr, "Error: Unable to allocate memory for array sizes.\n");
        exit(1);
    }
    
    sym->initialized = false;
    sym->parameters = NULL;
    sym->next = NULL;

    printf("DEBUG: Created symbol - name: %s, type: %d, is_array: %d\n", sym->name, sym->symbol_type, sym->is_array);

    return sym;
}



ParamNode* create_param_node(VarType type, const char* name) {
    if (name == NULL) {
        fprintf(stderr, "Error: Parameter name is NULL.\n");
        exit(1);
    }
    ParamNode* node = (ParamNode*)malloc(sizeof(ParamNode));
    if (!node) {
        fprintf(stderr, "Error: Unable to allocate memory for parameter node.\n");
        exit(1);
    }
    node->type = type;
    node->name = strdup(name);
    if (node->name == NULL) {
        fprintf(stderr, "Error: strdup failed for parameter name '%s'.\n", name);
        exit(1);
    }
    node->next = NULL;
    return node;
}



// Helper function to create a new function symbol
static Symbol* create_function_symbol(const char* name, VarType return_type, ParamNode* parameters) {
    Symbol* sym = create_symbol(name, SYMBOL_FUNCTION, return_type, false, 0, NULL);
    sym->return_type = return_type;
    sym->parameters = parameters;
    sym->initialized = true;

    // Debug each parameter in the parameters list
    printf("DEBUG: Verifying parameters for function '%s'\n", name);
    ParamNode* param = parameters;
    while (param) {
        if (!param->name) {
            fprintf(stderr, "Error: Null parameter name in function '%s'.\n", name);
            exit(1);
        }
        printf("DEBUG: Parameter - name: %s, type: %d\n", param->name, param->type);
        param = param->next;
    }

    return sym;
}


// Helper function to create a new variable symbol
static Symbol* create_variable_symbol(const char* name, VarType var_type, bool is_array, int num_dimensions, int* sizes) {
    if (name == NULL) {
        fprintf(stderr, "Error: Variable name is NULL in create_variable_symbol.\n");
        exit(1);
    }
    printf("DEBUG: Creating variable symbol with name = %s, type = %d\n", name, var_type);

    Symbol* sym = create_symbol(name, SYMBOL_VARIABLE, var_type, is_array, num_dimensions, sizes);
    if (!sym) {
        fprintf(stderr, "Error: Unable to allocate memory for new variable symbol.\n");
        exit(1);
    }

    printf("DEBUG: Created variable symbol - name: %s, type: %d, is_array: %d\n", sym->name, sym->var_type, sym->is_array);
    return sym;
}

void init_symbol_table() {
    symbol_table_stack = create_symbol_table();
    printf("DEBUG: Initialized symbol_table_stack = %p\n", (void*)symbol_table_stack);
}

void push_scope() {
    SymbolTable* new_table = create_symbol_table();
    new_table->next = symbol_table_stack;
    symbol_table_stack = new_table;

    printf("DEBUG: Pushed new scope. Current symbol_table_stack = %p\n", (void*)symbol_table_stack);

    // Check symbol table immediately after pushing
    if (symbol_table_stack == NULL) {
        fprintf(stderr, "Error: symbol_table_stack is NULL after pushing scope.\n");
        exit(1);
    }
    if (symbol_table_stack->symbols != NULL) {
        printf("DEBUG: New scope has symbols starting at %p\n", (void*)symbol_table_stack->symbols);
    } else {
        printf("DEBUG: New scope has no symbols initially.\n");
    }
}



void pop_scope() {
    if (symbol_table_stack == NULL) {
        fprintf(stderr, "Error: No scope to pop.\n");
        exit(1);
    }
    SymbolTable* temp = symbol_table_stack;
    symbol_table_stack = symbol_table_stack->next;
        printf("DEBUG: Popped scope. New symbol_table_stack = %p\n", (void*)symbol_table_stack);

    // Free all symbols in temp
    Symbol* sym = temp->symbols;
    while (sym) {
        Symbol* next_sym = sym->next;
        free(sym->name);
        if (sym->is_array && sym->sizes) {
            free(sym->sizes);
        }
        // If function, free parameters
        if (sym->symbol_type == SYMBOL_FUNCTION) {
            ParamNode* param = sym->parameters;
            while (param) {
                ParamNode* next_param = param->next;
                free(param->name);
                free(param);
                param = next_param;
            }
        }
        free(sym);
        sym = next_sym;
    }
    free(temp);
}

SymbolTable* current_scope_table() {
    printf("DEBUG: current_scope_table() = %p\n", (void*)symbol_table_stack);
    return symbol_table_stack;
}

bool add_variable(SymbolTable* table, const char* name, VarType type, bool is_array, int num_dimensions, int* sizes) {
    if (!name) {
        fprintf(stderr, "Error: Variable name is NULL in add_variable.\n");
        exit(1);
    }

    printf("DEBUG: add_variable called with name = %s, type = %d, table = %p\n", name, type, (void*)table);
    printf("DEBUG: Current symbol table before insertion, table->symbols = %p\n", (void*)table->symbols);

    Symbol* sym = table->symbols;
    while (sym) {
        if (sym->name == NULL) {
            fprintf(stderr, "Error: Symbol in symbol table has a NULL name.\n");
            exit(1);
        }
        if (strcmp(sym->name, name) == 0) {
            printf("DEBUG: Variable '%s' already exists in the current scope.\n", name);
            return false;
        }
        sym = sym->next;
    }

    // Create and add the new variable symbol
    Symbol* new_sym = create_variable_symbol(name, type, is_array, num_dimensions, sizes);
    new_sym->next = table->symbols;
    table->symbols = new_sym;

    // Print table symbols after insertion
    printf("DEBUG: Symbol table after inserting '%s', table->symbols = %p\n", name, (void*)table->symbols);
    return true;
}




bool add_function(SymbolTable* table, const char* name, VarType return_type, ParamNode* parameters) {
    printf("DEBUG: add_function called with table = %p, name = %s, return_type = %d, parameters = %p\n", 
           (void*)table, name, return_type, (void*)parameters);
    
    if (!table) {
        fprintf(stderr, "Error: Symbol table is NULL in add_function.\n");
        exit(1);
    }

    // Print existing symbols in the current table for debugging
    printf("DEBUG: Current symbols in the symbol table:\n");
    Symbol* temp_sym = table->symbols;
    while (temp_sym) {
        printf("  Symbol: %s, Type: %d\n", temp_sym->name, temp_sym->symbol_type);
        temp_sym = temp_sym->next;
    }

    // Check if the function already exists in the current scope
    Symbol* sym = table->symbols;
    while (sym) {
        if (strcmp(sym->name, name) == 0 && sym->symbol_type == SYMBOL_FUNCTION) {
            printf("DEBUG: Function '%s' already exists in the symbol table.\n", name);
            return false;
        }
        sym = sym->next;
    }

    // Debug each parameter's name to confirm initialization
    ParamNode* param = parameters;
    while (param) {
        if (!param->name) {
            fprintf(stderr, "Error: Parameter name is NULL in function '%s'.\n", name);
            exit(1);
        }
        printf("DEBUG: Parameter name for function '%s': %s\n", name, param->name);
        param = param->next;
    }

    // Create and add the new function symbol
    Symbol* new_sym = create_function_symbol(name, return_type, parameters);
    printf("DEBUG: Created new Symbol for function '%s' at %p\n", name, (void*)new_sym);
    new_sym->next = table->symbols;
    table->symbols = new_sym;
    return true;
}





Symbol* get_symbol(SymbolTable* table, const char* name) {
    SymbolTable* current = table;
    while (current) {
        Symbol* sym = current->symbols;
        while (sym) {
            if (strcmp(sym->name, name) == 0) {
                return sym;
            }
            sym = sym->next;
        }
        current = current->next;
    }
    return NULL; // Not found
}

bool function_exists(SymbolTable* table, const char* name) {
    Symbol* sym = get_symbol(table, name);
    if (sym && sym->symbol_type == SYMBOL_FUNCTION) {
        return true;
    }
    return false;
}

void print_symbol(Symbol* sym) {
    if (!sym) return;
    printf("Name: %s, Type: ", sym->name);

    if (sym->symbol_type == SYMBOL_VARIABLE) {
        printf("Variable, ");
        switch (sym->var_type) {
            case VAR_TYPE_INT:
                printf("int");
                break;
            case VAR_TYPE_FLOAT:
                printf("float");
                break;
            case VAR_TYPE_CHAR:
                printf("char");
                break;
            default:
                printf("unknown");
        }
        if (sym->is_array) {
            printf(", Array");
            printf(", Dimensions: %d", sym->num_dimensions);
            printf(", Sizes: [");
            for (int i = 0; i < sym->num_dimensions; ++i) {
                printf("%d", sym->sizes[i]);
                if (i < sym->num_dimensions -1 ) printf(", ");
            }
            printf("]");
        }
        printf(", Initialized: %s\n", sym->initialized ? "Yes" : "No");
    }
    else if (sym->symbol_type == SYMBOL_FUNCTION) {
        printf("Function, ");
        switch (sym->return_type) {
            case VAR_TYPE_INT:
                printf("Return Type: int");
                break;
            case VAR_TYPE_FLOAT:
                printf("Return Type: float");
                break;
            case VAR_TYPE_CHAR:
                printf("Return Type: char");
                break;
            default:
                printf("Return Type: unknown");
        }
        printf(", Parameters: None\n");
    }
}
void print_all_scopes() {
    SymbolTable* current = symbol_table_stack;
    int scope_level = 0;
    while (current) {
        printf("Scope Level %d:\n", scope_level);
        Symbol* sym = current->symbols;
        if (!sym) {
            printf("  (No symbols)\n");
        }
        while (sym) {
            printf("  ");
            print_symbol(sym);
            sym = sym->next;
        }
        current = current->next;
        scope_level++;
    }
}

void free_symbol_table(SymbolTable* table) {
    while (table) {
        SymbolTable* next_table = table->next;
        Symbol* sym = table->symbols;

        while (sym) {
            Symbol* next_sym = sym->next;

            if (sym->name) {
                free(sym->name);
            }

            if (sym->is_array && sym->sizes) {
                free(sym->sizes);
            }

            if (sym->symbol_type == SYMBOL_FUNCTION) {
                // Free the parameters list if it exists
                ParamNode* param = sym->parameters;
                while (param) {
                    ParamNode* next_param = param->next;
                    if (param->name) {
                        free(param->name);
                    }
                    free(param);
                    param = next_param;
                }
                sym->parameters = NULL;
            }

            free(sym);
            sym = next_sym;
        }

        free(table);
        table = next_table;
    }
}


ParamList* create_param_list() {
    printf("DEBUG: create_param_list() called.\n");
    ParamList* list = (ParamList*)malloc(sizeof(ParamList));
    if (!list) {
        fprintf(stderr, "Error: Unable to allocate memory for ParamList.\n");
        exit(1);
    }
    list->symbols = NULL;
    list->ast_params = NULL;
    return list;
}


// Add a ParamNode to ParamList
ParamList* add_to_param_list(ParamList* list, ParamNode* param) {
    if (!list) {
        list = create_param_list(); 
    }
    param->next = list->symbols;
    list->symbols = param;
    return list;
}
void free_all_symbol_tables() {
    if (symbol_table_stack != NULL) {
        free_symbol_table(symbol_table_stack);
        symbol_table_stack = NULL;
    }
}