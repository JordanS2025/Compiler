// ast.h

#ifndef AST_H
#define AST_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "types.h"  // Ensure this header defines VarType and related types
#define MAX_DIMENSIONS 10

// Enumeration for different types of AST nodes
typedef enum {
    NODE_PROGRAM,
    NODE_FUNCTION_DEF,
    NODE_MAIN_FUNCTION,
    NODE_BLOCK,              // New node type for function bodies
    NODE_VAR_DECL,
    NODE_ARRAY_DECL,
    NODE_ASSIGNMENT,
    NODE_ARRAY_ASSIGNMENT,
    NODE_WRITE,
    NODE_WRITE_ARRAY,
    NODE_BINARY_OP,
    NODE_FUNCTION_CALL,
    NODE_ARRAY_ACCESS,
    NODE_ID,
    NODE_NUMBER,
    NODE_FLOAT,
    NODE_RETURN,
    NODE_AST_PARAM,          // Renamed from NODE_PARAM
    NODE_AST_PARAM_LIST,     // Renamed from NODE_PARAM_LIST
    // NODE_AST_ARG_LIST,    // Removed as per updates
    NODE_INITIALIZER_LIST,
    NODE_ARRAY_SIZE,
    NODE_ARG                // New node type for function call arguments
} NodeType;

// Forward declarations
struct ASTNode;
struct ASTParamNode;

// Structure for function parameters
typedef struct ASTParamNode {
    char* type;
    char* name;
    struct ASTParamNode* next;
} ASTParamNode;

// Structure for AST nodes
typedef struct ASTNode {
    NodeType node_type;
    char* name;                   // For identifiers (e.g., variable names, function names)
    char* data_type;              // "int", "float", "char", etc.
    struct ASTNode* left;        // Left child (e.g., first operand in binary operations)
    struct ASTNode* right;       // Right child (e.g., second operand in binary operations)
    struct ASTNode* child;       // Single child (e.g., body of a function or block)
    struct ASTNode* next;        // Next node in a list (e.g., list of functions, parameters, statements)

    // Specific fields for certain node types
    int value;                    // For number literals
    float float_value;            // For float literals

    // For array declarations and accesses
    int num_dimensions;
    int sizes[MAX_DIMENSIONS];

    // For function parameters and arguments
    struct ASTParamNode* params;  // Linked list of parameters (for function definitions)
    struct ASTNode* args;         // Linked list of arguments (for function calls)

    // Additional fields can be added as needed
} ASTNode;

// Structure for parameter lists
typedef struct ASTParamList {
    ASTParamNode* params;
} ASTParamList;

// Function declarations

// Program Node
ASTNode* create_program_node(ASTNode* functions, ASTNode* main_func);
const char* var_type_to_string(VarType type);
ASTParamList* add_ast_param(ASTParamList* list, ASTParamNode* param_node);

// Function Definitions List
ASTNode* add_to_function_list(ASTNode* list, ASTNode* func);

// Function Definition Node
ASTNode* create_function_def_node(const char* return_type, const char* name, ASTParamNode* params, ASTNode* body);

// Main Function Node
ASTNode* create_main_function_node(ASTNode* body);

// Parameter Node (renamed)
ASTParamNode* create_ast_param_node(const char* type, const char* name);

// Parameter List Node
ASTNode* create_ast_param_list_node(ASTParamNode* param);

// Add to Parameter List
ASTParamNode* add_to_ast_param_list(ASTParamNode* list, ASTParamNode* param);

// Variable Declaration Node
ASTNode* create_var_decl_node(const char* type, const char* name, ASTNode* array_sizes, ASTNode* initializer);

// Array Declaration Node
ASTNode* create_array_decl_node(const char* type, const char* name, ASTNode* array_sizes, ASTNode* initializer);

// Assignment Node
ASTNode* create_assignment_node(const char* name, ASTNode* expr);

// Array Assignment Node
ASTNode* create_array_assignment_node(const char* name, ASTNode* index, ASTNode* expr);

// Write Statement Node
ASTNode* create_write_node(const char* name);

// Write Array Element Node
ASTNode* create_write_node_with_access(const char* name, ASTNode* index);

// Binary Operation Node
ASTNode* create_binary_op_node(const char* op, ASTNode* left, ASTNode* right);

// Function Call Node
ASTNode* create_function_call_node(const char* name, ASTNode* args);

// Array Access Node
ASTNode* create_array_access_node(const char* name, ASTNode* index);

// Identifier Node
ASTNode* create_id_node(const char* name);

// Number Literal Node
ASTNode* create_number_node(int value);

// Float Literal Node
ASTNode* create_float_node(float value);

// Return Statement Node
ASTNode* create_return_node(ASTNode* expr);

// Function Body Node
ASTNode* create_function_body_node(ASTNode* declarations, ASTNode* statements, ASTNode* return_stmt);

// Main Body Node
ASTNode* create_main_body_node(ASTNode* declarations, ASTNode* statements, ASTNode* return_stmt);

// Variable Declaration List
ASTNode* add_to_var_decl_list(ASTNode* list, ASTNode* decl);

// Statement List
ASTNode* add_to_stmt_list(ASTNode* list, ASTNode* stmt);

// Initializer List
ASTNode* add_to_initializer_list(ASTNode* list, ASTNode* initializer);

// Argument Node
ASTNode* create_arg_node(ASTNode* expr);

// Add to Argument List
ASTNode* add_to_arg_list(ASTNode* list, ASTNode* arg);

// Free AST
void free_ast(ASTNode* root);

// Create a new array size node
ASTNode* create_array_size_node(int size);

// Add a size to an existing array size node
void add_array_size(ASTNode* node, int size);

// Traverse AST (for debugging)
void traverse_ast(ASTNode* node, int level);

#endif // AST_H
