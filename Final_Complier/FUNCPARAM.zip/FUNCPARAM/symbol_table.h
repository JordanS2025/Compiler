#ifndef SYMBOL_TABLE_H
#define SYMBOL_TABLE_H

#include <stdbool.h>
#include "types.h"

// Enumeration for symbol types
typedef enum {
    SYMBOL_VARIABLE,
    SYMBOL_FUNCTION
} SymbolType;

// Structure for function parameters
typedef struct ParamNode {
    VarType type;
    char* name;
    struct ParamNode* next;
} ParamNode;

// Forward declaration for ASTParamList
struct ASTParamList;

// Structure for symbol
typedef struct Symbol {
    char* name;
    SymbolType symbol_type;
    VarType var_type; // Valid if symbol_type == SYMBOL_VARIABLE
    bool is_array;
    int num_dimensions;
    int* sizes; // Array sizes if is_array is true
    bool initialized; // For variables
    // For functions
    VarType return_type; // Valid if symbol_type == SYMBOL_FUNCTION
    ParamNode* parameters; // Valid if symbol_type == SYMBOL_FUNCTION
    struct Symbol* next; // For chaining in symbol table
} Symbol;

typedef struct ParamList {
    ParamNode* symbols;           // List of parameters for the symbol table
    struct ASTParamList* ast_params; // Corresponding AST parameter list
} ParamList;

// Structure for symbol table (a linked list of symbols)
typedef struct SymbolTable {
    Symbol* symbols; // Head of symbols linked list
    struct SymbolTable* next; // Next symbol table in the stack (for scopes)
} SymbolTable;

// Function to initialize the symbol table stack (push global scope)
void init_symbol_table();

// Function to push a new scope onto the symbol table stack
void push_scope();

// Function to pop the current scope from the symbol table stack
void pop_scope();

// Function to get the current scope's symbol table
SymbolTable* current_scope_table();

// Function to add a variable to the current scope
// Returns true on success, false if variable already exists
bool add_variable(SymbolTable* table, const char* name, VarType type, bool is_array, int num_dimensions, int* sizes);

// Function to add a function to the current scope
// For functions, parameters are in ParamNode linked list
// Returns true on success, false if function already exists
bool add_function(SymbolTable* table, const char* name, VarType return_type, ParamNode* parameters);

// Function to get a symbol by name, searching from current scope upwards
Symbol* get_symbol(SymbolTable* table, const char* name);

// Function to check if a function exists (searching from current scope upwards)
bool function_exists(SymbolTable* table, const char* name);

// Function to print all symbol tables (for debugging)
void print_all_scopes();

// Function to free all symbol tables and symbols
void free_all_symbol_tables();

// Helper functions for ParamNode
ParamNode* create_param_node(VarType type, const char* name);
ParamList* add_to_param_list(ParamList* list, ParamNode* param);

// **Add the missing declaration here**
ParamList* create_param_list();

#endif // SYMBOL_TABLE_H
